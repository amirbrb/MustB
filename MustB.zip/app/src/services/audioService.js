module.exports = {
	captureMediaAndGetFile (success, failure, settings){

	},
	playFile (filePath){

	}
}