module.exports = {
	mail: 1,
	google: 2,
	facebook: 3
}