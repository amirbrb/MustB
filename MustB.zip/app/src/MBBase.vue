<script>

export default {
  data() {
	return {
			domain: 'http://localhost:3000',
  		loginType: {
				"mail":1,
  			"google": 2, 
  			"facebook": 3
  		}  
	}
  }
}

</script>
