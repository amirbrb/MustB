const jsonSuccess = require('../models/jsonSuccess');
const userModel = require('../models/user');
const registrationResponse = require('../models/registration/registrationResponse');
const loginResponse = require('../models/registration/loginResponse');


const loginType = {
  mail: 1,
  google: 2, 
  facebook: 3
}

const mockUserData = [{
	"uid": "1",
	"mail": "a@a.com", 
	"password": "aaa", 
	"firstName": "amir",
	"lastName": "mishori",
	"phoneNumber": "0547772344",
	"avatar": "avatar.jpg",
	"showLocation": false,
	"settings": {
		"loginType": loginType.mail,
		"sosControlLocation": {
			
		}
	}
}];

module.exports = {
	register: function(mail, password, firstName, lastName, phoneNumber){
		var existingUser = mockUserData.find(function(user){
			return user.mail === mail;
		});

		if(existingUser){
			return registrationResponse(false, null, "sorry, provided mail is used");	
		}

		//insert user to db and return model
		let userId = mockUserData.length + 1;
		let user = userModel(firstName, lastName, '/images/avatar.png', userId, {
			sosControlLocation: mockUserData.settings.sosControlLocation
		});
		return registrationResponse(true, user);
	},
	login: function(mail, password){
		
		var existingUser = mockUserData.find(function(user){
			return user.mail === mail;
		});

		if(existingUser){
			if(existingUser.password !== password)
				return loginResponse(false, null, "sorry, password is incorrect");	
			else
			{
				var imageUrl = '/images/user/' + existingUser.uid + '/' + existingUser.avatar;
				let user = userModel(existingUser.firstName, existingUser.lastName, imageUrl, existingUser.uid, {
					sosControlLocation: existingUser.settings.sosControlLocation
				})
				return loginResponse(true, user);	
			}
		}else{
			return loginResponse(false, null, 'sorry, could not find this user');	
		}
	},
	getUserByName: function(mail, password){
		
		var existingUser = mockUserData.find(function(user){
			return user.mail === mail;
		});

		if(existingUser){
			var imageUrl = '/images/user/' + existingUser.uid + '/' + existingUser.avatar;
			let user = userModel(existingUser.firstName, existingUser.lastName, imageUrl, existingUser.uid, {
				sosControlLocation: existingUser.settings.sosControlLocation
			})
			return loginResponse(true, user);	
		}else{
			return loginResponse(false, null, 'sorry, could not find this user');	
		}
	}, 
	updateSettings: function(settings, uid){
		var existingUser = mockUserData.find(function(user){
			return user.uid === uid;
		});

		if(existingUser){
			existingUser.settings = settings;
		}
	}
}