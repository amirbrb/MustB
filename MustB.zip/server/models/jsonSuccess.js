module.exports = function(data){
	return {
		isSuccess: true,
		data: data
	}
}