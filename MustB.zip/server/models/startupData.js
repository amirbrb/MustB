module.exports = function(userData){
	return {
		userData: userData
	};
}